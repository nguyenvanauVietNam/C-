#ifndef TRAFFICLIGHT_H
#define TRAFFICLIGHT_H

#include <mutex>
#include <deque>
#include <condition_variable>
#include "TrafficObject.h"

// forward declarations to avoid include cycle
class Vehicle;
/// [AuNV] [2023/10/04] add new code -----> 
struct Timer {
    std::chrono::time_point<std::chrono::system_clock> l_start, l_end;
    std::chrono::duration<float> l_interval{0.0};
    Timer()
    {
        l_start = std::chrono::high_resolution_clock::now();
    }
    ~Timer()
    {
        l_end = std::chrono::high_resolution_clock::now();
        l_interval = l_end - l_start;
    }
};
/// [AuNV] [2023/10/04]  <----- 

// FP.3 Define a class „MessageQueue“ which has the public methods send and receive. 
// Send should take an rvalue reference of type TrafficLightPhase whereas receive should return this type. 
// Also, the class should define an std::dequeue called _queue, which stores objects of type TrafficLightPhase. 
// Also, there should be an std::condition_variable as well as an std::mutex as private members. 

template <class T>
class MessageQueue
{
public:
    /// [AuNV] [2023/10/04] add new code -----> 
    void send(T&& l_msg);
    T receive();
    /// [AuNV] [2023/10/04]  <----- 
private:
    /// [AuNV] [2023/10/04] add new code -----> 
    std::deque<T> _queue;
    std::condition_variable _cond;
    std::mutex _mutex;
    /// [AuNV] [2023/10/04]  <----- 
};

// FP.1 : Define a class „TrafficLight“ which is a child class of TrafficObject. 
// The class shall have the public methods „void waitForGreen()“ and „void simulate()“ 
// as well as „TrafficLightPhase getCurrentPhase()“, where TrafficLightPhase is an enum that 
// can be either „red“ or „green“. Also, add the private method „void cycleThroughPhases()“. 
// Furthermore, there shall be the private member _currentPhase which can take „red“ or „green“ as its value. 
/// [AuNV] [2023/10/04] mod code -----> 
//class TrafficLight
class TrafficLight : public TrafficObject
/// [AuNV] [2023/10/04]  <-----
{
public:
    // constructor / desctructor
    TrafficLight(); /// [AuNV] [2023/10/04] add new code /
    // getters / setters

    // typical behaviour methods
    /// [AuNV] [2023/10/04] add new code -----> 
    void simulate();
    enum TrafficLightPhase { red, green };
    TrafficLightPhase waitForGreen();
    TrafficLightPhase getCurrentPhase();
    /// [AuNV] [2023/10/04]  <----- 

private:
    // typical behaviour methods

    // FP.4b : create a private member of type MessageQueue for messages of type TrafficLightPhase 
    // and use it within the infinite loop to push each new TrafficLightPhase into it by calling 
    // send in conjunction with move semantics.
    /// [AuNV] [2023/10/04] add new code -----> 
    void cycleThroughPhases();
    TrafficLightPhase m_currentPhase;
    std::shared_ptr<MessageQueue<TrafficLightPhase>> m_messageQueue = std::make_shared<MessageQueue<TrafficLightPhase>>();
    /// [AuNV] [2023/10/04]  <----- 
    std::condition_variable _condition;
    std::mutex _mutex;
};

#endif