#include <iostream>
#include <random>
#include "TrafficLight.h"
/// [AuNV] [2023/10/04] add new code -----> 
//include library
#include <chrono>
#include <future>

using namespace std::chrono_literals;
std::random_device l_radom_device;
std::mt19937 l_generation(l_radom_device());
std::uniform_real_distribution<> l_distribution(4, 6);
/// [AuNV] [2023/10/04]  <----- 
/* Implementation of class "MessageQueue" */


template <typename T>
T MessageQueue<T>::receive()
{
    // FP.5a : The method receive should use std::unique_lock<std::mutex> and _condition.wait() 
    // to wait for and receive new messages and pull them from the queue using move semantics. 
    // The received object should then be returned by the receive function. 
    /// [AuNV] [2023/10/04] add new code -----> 
    std::unique_lock<std::mutex> ulock(_mutex);
    _cond.wait(ulock, [this]() {
        return !_queue.empty();
        });
    T l_currentLight = std::move(_queue.back());
    return l_currentLight;
    /// [AuNV] [2023/10/04]  <----- 
}

template <typename T>
void MessageQueue<T>::send(T &&l_msg)
{
    // FP.4a : The method send should use the mechanisms std::lock_guard<std::mutex> 
    // as well as _condition.notify_one() to add a new message to the queue and afterwards send a notification.
    /// [AuNV] [2023/10/04] add new code -----> 
    std::lock_guard<std::mutex> lock(_mutex);
    _queue.clear();
    _queue.emplace_back(std::move(l_msg));
    _cond.notify_one();
    /// [AuNV] [2023/10/04]  <----- 
}

/* Implementation of class "TrafficLight" */


TrafficLight::TrafficLight()
{
    /// [AuNV] [2023/10/04] mod code -----> 
    //_currentPhase = TrafficLightPhase::red;
    m_currentPhase = TrafficLightPhase::red;
    /// [AuNV] [2023/10/04]  <----- 
}

/// [AuNV] [2023/10/04] mod code -----> 
//void TrafficLight::waitForGreen()
TrafficLight::TrafficLightPhase TrafficLight::waitForGreen()
{
    // FP.5b : add the implementation of the method waitForGreen, in which an infinite while-loop 
    // runs and repeatedly calls the receive function on the message queue. 
    // Once it receives TrafficLightPhase::green, the method returns.
    while (true)
    {
        TrafficLightPhase l_currentLight = m_messageQueue->receive();
        if (l_currentLight == green)
            return l_currentLight;
    }
}
/// [AuNV] [2023/10/04]  <----- 

/// [AuNV] [2023/10/04] mod code -----> 
//TrafficLightPhase TrafficLight::getCurrentPhase()
TrafficLight::TrafficLightPhase TrafficLight::getCurrentPhase()
/// [AuNV] [2023/10/04]  <----- 
{
    return m_currentPhase;
}

void TrafficLight::simulate()
{
    // FP.2b : Finally, the private method „cycleThroughPhases“ should be started in a thread when the public method „simulate“ is called. To do this, use the thread queue in the base class. 
    /// [AuNV] [2023/10/04] add new code -----> 
    threads.emplace_back(std::thread(&TrafficLight::cycleThroughPhases, this));
    /// [AuNV] [2023/10/04]  <----- 
}

// virtual function which is executed in a thread
void TrafficLight::cycleThroughPhases()
{
    // FP.2a : Implement the function with an infinite loop that measures the time between two loop cycles 
    // and toggles the current phase of the traffic light between red and green and sends an update method 
    // to the message queue using move semantics. The cycle duration should be a random value between 4 and 6 seconds. 
    // Also, the while-loop should use std::this_thread::sleep_for to wait 1ms between two cycles. 
    /// [AuNV] [2023/10/04] add new code -----> 
    std::chrono::duration<float> l_timeSinceLastUpdate;
    std::chrono::time_point<std::chrono::system_clock> l_start, l_end;

    while (true)
    {
        float randomSeconds = l_distribution(l_generation);

        l_start = std::chrono::high_resolution_clock::now();
        std::this_thread::sleep_for(std::chrono::seconds(static_cast<int>(randomSeconds)));

        if (m_currentPhase == green)
        {
            m_currentPhase = red;
        }
        else
        {
            m_currentPhase = green;
        }

        l_timeSinceLastUpdate = std::chrono::duration<float>::zero();
        l_end = std::chrono::high_resolution_clock::now();
        l_timeSinceLastUpdate += (l_end - l_start);

        m_messageQueue->send(std::move(m_currentPhase));
    }
    /// [AuNV] [2023/10/04]  <----- 
}
