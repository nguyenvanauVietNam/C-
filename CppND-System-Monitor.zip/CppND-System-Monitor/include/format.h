#ifndef FORMAT_H
#define FORMAT_H

#include <string>

namespace Format {
std::string ElapsedTime(long times);  // TODO: See src/format.cpp
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
//Convert Time to string
std::string ConvertTimeValueToString(long time);
//[AuNV] (2023/10/02) <-----
};                                    // namespace Format

#endif