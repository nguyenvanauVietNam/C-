#ifndef PROCESSOR_H
#define PROCESSOR_H
#include <vector>
#include <string>
class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp

  // TODO: Declare any necessary private members
  //[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
  // constructor
  Processor();
  ~Processor();
  // convert the given string vector into a long vector
  std::vector<long> convertToLong(std::vector<std::string> values);
private:
    //attribu
    float prevTotalCpuTime;
    float prevIdleCpuTime;
  //[AuNV] (2023/10/02) <-----

};

#endif