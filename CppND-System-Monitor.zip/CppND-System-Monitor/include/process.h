#ifndef PROCESS_H
#define PROCESS_H

#include <string>
/*
Basic class for Process representation
It contains relevant attributes as shown below
*/
class Process {
 public:
  int Pid();                               // TODO: See src/process.cpp
  std::string User();                      // TODO: See src/process.cpp
  std::string Command() ;                   // TODO: See src/process.cpp
  float CpuUtilization()const;                  // TODO: See src/process.cpp
  std::string Ram();                       // TODO: See src/process.cpp
  long int UpTime();                       // TODO: See src/process.cpp
  bool operator<(Process const& a) const;  // TODO: See src/process.cpp

  // TODO: Declare any necessary private members
  // constructor to initialize Process with the read process-ID from filesystem
  Process(int pid);
  //Destructor
  ~Process();
 private:
   //Attribu
  // process-ID
  int processId_;
  // user name that generated this process
  std::string user_;
  // command that generated this process
  std::string command_;
  // CPU usage of the process
  float cpuUsage_;
  // processes memory utilization
  std::string ram_;
  // age of this process
  long uptime_;
   // CPU values of a process
  enum ProcessCPUStates {
    kUtime_ = 0,
    kStime_,
    kCutime_,
    kCstime_,
    kStarttime_
  };

};

#endif