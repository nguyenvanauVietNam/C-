#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"
#include "linux_parser.h"//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

using std::string;
using std::to_string;
using std::vector;

//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
 // initialize all values by Constructor
 Process::Process(int pid)
 {
    // process-ID
    processId_ = pid;
    // user name that generated this process
    user_ = LinuxParser::User(Pid());
    // command that generated this process
     command_ = LinuxParser::Command(Pid());
    // CPU usage of the process
     long l_uptime = LinuxParser::UpTime();
     long l_totalTime = LinuxParser::ActiveJiffies(pid);
     cpuUsage_ = float(l_totalTime) / float(l_uptime);
   
    // processes memory utilization
    auto l_ram = LinuxParser::Ram(Pid());
    try {
        long l_convert_ram_to_string= std::stol(l_ram) / 1000;
        ram_ = std::to_string(l_convert_ram_to_string);
    } catch (const std::invalid_argument& arg) {
        ram_ = "0"; //if not convert 
    }
    // age of this process
    uptime_ = LinuxParser::UpTime(Pid());
 }
 //Destructor
 Process::~Process()
{
    processId_ = 0;
    user_ = "n/a";
    cpuUsage_ = 0;
    uptime_ = 0;
    ram_ = "0";
}
//[AuNV] (2023/10/02) <-----

// TODO: Return this process's ID
int Process::Pid() { return processId_; }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() const { return cpuUsage_; }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the command that generated this process
string Process::Command()  { return command_; }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return this process's memory utilization
string Process::Ram()  { return ram_; }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the user (name) that generated this process
string Process::User()   { return user_; }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the age of this process (in seconds)
long int Process::UpTime()  { return uptime_; }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a) const //{ return true; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
     return CpuUtilization() < a.CpuUtilization();
}
//[AuNV] (2023/10/02) <-----