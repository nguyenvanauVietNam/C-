#include <string>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
//string Format::ElapsedTime(long seconds[[maybe_unused]]) { return string(); }
string Format::ElapsedTime(long l_seconds) {
  std::string l_time {"00:00:00"};
  long l_calculatorTime{0};
  if (l_seconds > 0) {
    // calculate hours
    l_calculatorTime = l_seconds / 3600;
    l_time = ConvertTimeValueToString(l_calculatorTime) + ":";
    // calculate minutes
    l_calculatorTime = (l_seconds / 60) % 60;
    l_time += ConvertTimeValueToString(l_calculatorTime) + ":";
    // calculate seconds
    l_calculatorTime = l_seconds % 60;
    l_time += ConvertTimeValueToString(l_calculatorTime);
  }

  return l_time;
}

//Convert Time to string
// if time < 10 add '0' to time , else return time.
std::string Format::ConvertTimeValueToString(long time)
{
    return (time < 10) ? ("0" + std::to_string(time)) : std::to_string(time);
}
//[AuNV] (2023/10/02) <-----

