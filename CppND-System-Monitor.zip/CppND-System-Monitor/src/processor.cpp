#include "processor.h"
#include <string>
#include <vector>
#include "linux_parser.h"

using std::string;
using std::vector;


//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
//Constructor
Processor::Processor()
{
    prevTotalCpuTime = 0.0;
    prevIdleCpuTime = 0.0;
}
//Destructor
Processor::~Processor()
{

}
// convert the given string vector into a long vector
vector<long> Processor::convertToLong(vector<string> values) {
  vector<long> l_convertedValues{};

  for (int it = 0; it < (int)values.size(); it++) {
    try {
      l_convertedValues.push_back(std::stol(values[it]));
    } catch (const std::invalid_argument& arg) {
      l_convertedValues.push_back((long)0);
    }
  }
  return l_convertedValues;
}
//[AuNV] (2023/10/02) <-----

// TODO: Return the aggregate CPU utilization
float Processor::Utilization()// { return 0.0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  // read current cpu values from file system
  vector<long> l_cpuValues = convertToLong(LinuxParser::CpuUtilization());
  // total cpu time since boot = user+nice+system+idle+iowait+irq+softirq+steal
  float l_totalCpuTime =
      l_cpuValues[LinuxParser::kUser_] + l_cpuValues[LinuxParser::kNice_] +
      l_cpuValues[LinuxParser::kSystem_] + l_cpuValues[LinuxParser::kIdle_] +
      l_cpuValues[LinuxParser::kIOwait_] + l_cpuValues[LinuxParser::kIRQ_] +
      l_cpuValues[LinuxParser::kSoftIRQ_] + l_cpuValues[LinuxParser::kSteal_];
  // idle time since boot = idle + iowait
  float l_idleCpuTime =
      l_cpuValues[LinuxParser::kIdle_] + l_cpuValues[LinuxParser::kIOwait_];

  // calculate the cpu usage since last update
  float l_diffIdle = l_idleCpuTime - prevIdleCpuTime;
  float l_diffTotal = l_totalCpuTime - prevTotalCpuTime;
  float l_diffUsage = (l_diffTotal - l_diffIdle) / l_diffTotal;
  // remember the total and idle times for next check
  prevIdleCpuTime = l_idleCpuTime;
  prevTotalCpuTime = l_totalCpuTime;
  return l_diffUsage;
}
//[AuNV] (2023/10/02) <-----