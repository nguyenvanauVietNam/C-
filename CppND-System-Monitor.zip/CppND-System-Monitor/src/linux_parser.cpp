#include <dirent.h>
#include <unistd.h>
#include <sstream>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel, version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() //{ return 0.0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  string l_line;
  string l_key;
  string l_value;

  // read file /proc/meminfo and look for MemTotal and MemFree
  std::ifstream l_filestream(kProcDirectory + kMeminfoFilename);
  long l_totalMemory{ 0 };
  long l_freeMemory{ 0 };

  if (l_filestream.is_open()) {
      while (std::getline(l_filestream, l_line)) {
          std::istringstream l_linestream(l_line);
          //remove 'KB"
          std::remove(l_line.begin(), l_line.end(), ' ');
          std::replace(l_line.begin(), l_line.end(), ':', ' ');
          l_linestream >> l_key >> l_value;
          if (l_key == "MemTotal:") {
              l_totalMemory = std::stol(l_value);
          }
          else if (l_key == "MemFree:") {
              l_freeMemory = std::stol(l_value);
              break;
          }
      }
  }

  float l_memoryUtilization{ 0 };
  l_memoryUtilization = (l_totalMemory - l_freeMemory) / static_cast<float>(l_totalMemory);
  return l_memoryUtilization;
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the system uptime
long LinuxParser::UpTime() //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::ifstream l_filestream(kProcDirectory + kUptimeFilename);
  if (l_filestream.is_open()) {
    string l_line{""};
    string l_result{""};
    // std::string line;
    // std::getline(filestream, line);
    // std::istringstream linestream(line);
    // long uptime;
    // linestream >> uptime;
      while (std::getline(l_filestream, l_line)) {
        std::istringstream l_ilinestream(l_line);
        while (l_ilinestream >> l_result) {
          try {
            return std::stol(l_result); //convert result to long
          } catch (const std::invalid_argument& arg) {
            return 0;
          }
        }
      }
    }
  return 0; // Return 0 if the file cannot be opened or read
}
//[AuNV] (2023/10/02) <-----
// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::vector<std::string> l_cpuUtilization = LinuxParser::CpuUtilization();
  long l_jiffies {0};
  for (const std::string& l_utilization : l_cpuUtilization) {
    l_jiffies += std::stol(l_utilization);
  }
  return l_jiffies;
}
//[AuNV] (2023/10/02) <-----
// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid) //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::ifstream l_filestream(kProcDirectory + std::to_string(pid) + kStatFilename);
  if (l_filestream.is_open()) {
    std::getline(l_filestream, l_line);
    std::istringstream l_ilinestream(l_line);
    std::istream_iterator<std::string> beg(l_ilinestream), end;
    std::vector<std::string> statValues(beg, end);
    long l_utime = std::stol(statValues[13]);
    long l_stime = std::stol(statValues[14]);
    long l_cutime = std::stol(statValues[15]);
    long l_cstime = std::stol(statValues[16]);
    return l_utime + l_stime + l_cutime + l_cstime;
  }
  return 0; // Return 0 if the file cannot be opened or read
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::vector<std::string> l_cpuUtilization = LinuxParser::CpuUtilization();
  long l_activeJiffies = std::stol(l_cpuUtilization[LinuxParser::kUser_]) +
                       std::stol(l_cpuUtilization[LinuxParser::kNice_]) +
                       std::stol(l_cpuUtilization[LinuxParser::kSystem_]) +
                       std::stol(l_cpuUtilization[LinuxParser::kIRQ_]) +
                       std::stol(l_cpuUtilization[LinuxParser::kSoftIRQ_]) +
                       std::stol(l_cpuUtilization[LinuxParser::kSteal_]);
  return l_activeJiffies;
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::vector<std::string> l_cpuUtilization = LinuxParser::CpuUtilization();
  long l_idleJiffies = std::stol(l_cpuUtilization[LinuxParser::kIdle_]) +
                     std::stol(l_cpuUtilization[LinuxParser::kIOwait_]);
  return l_idleJiffies;
}
//[AuNV] (2023/10/02) <-----
// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization()// { return {}; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
    std::vector<std::string> l_cpuUtilization{};
  //AuNV modify code after sefl-review 2023/09/30  ----->
  std::ifstream l_filestream(kProcDirectory + kStatFilename);
   std::string l_line{""};
  
  // if (filestream.is_open()) {
  //  std::getline(l_filestream, l_line);
  //   std::istringstream l_islinestream(l_line);
  //   std::istream_iterator<std::string> beg(l_islinestream), end;
  //   l_cpuUtilization = std::vector<std::string>(beg, end);
  // }
  std::string l_key{""},l_vuser{""}, l_vnice{""}, l_vsystem{""}, l_vidle{""}, l_viowait{""}, l_virq{""}, l_vsoftirq{""}, l_vsteal{""}, l_vguest{""}, l_vguest_nice{""};
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::istringstream l_islinestream(l_line);
      while (l_islinestream >> l_key >> l_vuser >> l_vnice >> l_vsystem >> l_vidle >>
             l_viowait >> l_virq >> l_vsoftirq >> l_vsteal >> l_vguest >> l_vguest_nice) {
        if (l_key == "cpu") {
          l_cpuUtilization.push_back(l_vuser);
          l_cpuUtilization.push_back(l_vnice);
          l_cpuUtilization.push_back(l_vsystem);
          l_cpuUtilization.push_back(l_vidle);
          l_cpuUtilization.push_back(l_viowait);
          l_cpuUtilization.push_back(l_virq);
          l_cpuUtilization.push_back(l_vsoftirq);
          l_cpuUtilization.push_back(l_vsteal);
          l_cpuUtilization.push_back(l_vguest);
          l_cpuUtilization.push_back(l_vguest_nice);
          //return l_cpuUtilization;
        }
      }
    }
  }
  //AuNV modify code after sefl-review   <-----
    return l_cpuUtilization; // return {} if don't find "cpu"
}

//Get CPU Untilization with pid
std::vector<float> LinuxParser::CpuUtilization(int pid) {
    std::vector<float> l_cpu_utilization{};
    std::string l_line{""};
    
    // Open the /proc/stat file
    std::ifstream l_filestream(kProcDirectory + kStatFilename);
    
    if (l_filestream.is_open()) {
        // Read lines until we find the line for the specified CPU core
        std::string l_target_cpu = "cpu" + std::to_string(pid);
        while (std::getline(l_filestream, l_line)) {
            // Check if the line starts with the target CPU name
            if (l_line.compare(0, l_target_cpu.length(), l_target_cpu) == 0) {
                // Split the line into tokens
                std::istringstream l_islinestream(l_line);
                std::istream_iterator<std::string> beg(l_islinestream), end;
                std::vector<std::string> l_tokens(beg, end);
                
                // Calculate the CPU utilization for each field
                float l_user = std::stof(l_tokens[1]);
                float l_nice = std::stof(l_tokens[2]);
                float l_system = std::stof(l_tokens[3]);
                float l_idle = std::stof(l_tokens[4]);
                float l_iowait = std::stof(l_tokens[5]);
                float l_irq = std::stof(l_tokens[6]);
                float l_softirq = std::stof(l_tokens[7]);
                float l_steal = std::stof(l_tokens[8]);
                float l_guest = std::stof(l_tokens[9]);
                float l_guest_nice = std::stof(l_tokens[10]);

                // Calculate total utilization
                float l_total_utilization = l_user + l_nice + l_system + l_idle + l_iowait + l_irq + l_softirq + l_steal + l_guest + l_guest_nice;

                // Calculate and store individual CPU utilization percentages
                l_cpu_utilization.push_back(l_user / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_nice / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_system / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_idle / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_iowait / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_irq / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_softirq / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_steal / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_guest / l_total_utilization * 100.0);
                l_cpu_utilization.push_back(l_guest_nice / l_total_utilization * 100.0);
                
                // Exit the loop once we've found the target CPU data
                break;
            }
        }
    }
    
    return l_cpu_utilization;
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::string l_key{""};
  int l_value {0};
  std::ifstream l_filestream(kProcDirectory + kStatFilename);
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::istringstream l_islinestream(l_line);
      l_islinestream >> l_key >> l_value;
      if (l_key == "processes") {
        return l_value;
      }
    }
  }
  return l_value; // Return 0 if the file cannot be opened or if the key is not found
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::string l_key{""};
  int l_value {0};
  std::ifstream l_filestream(kProcDirectory + kStatFilename);
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::istringstream l_islinestream(l_line);
      l_islinestream >> l_key >> l_value;
      if (l_key == "procs_running") {
        return l_value;
      }
    }
  }
  return l_value; // Return 0 if the file cannot be opened or if the key is not found
}
//[AuNV] (2023/10/02) <-----
// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) //{ return string(); }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::ifstream l_filestream(kProcDirectory + "/" + std::to_string(pid) + kCmdlineFilename);
  std::string l_line{""};
  
  if (l_filestream.is_open()) {
    std::getline(l_filestream, l_line);
  }
  
  return l_line;
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) //{ return string(); }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::string l_key{""};
  std::string l_value {0};
  std::ifstream l_filestream(kProcDirectory +"/"+ std::to_string(pid) + kStatusFilename);
  
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::istringstream l_islinestream(l_line);
      l_islinestream >> l_key >> l_value;
      if (l_key == "VmSize:") {
        return l_value;
      }
    }
  }
  return l_value;
}
//[AuNV] (2023/10/02) <-----
// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) //{ return string(); }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::string l_key{""};
  std::string l_uid {""};
  std::ifstream l_filestream(kProcDirectory + "/" + std::to_string(pid) + kStatusFilename);
  
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::istringstream linestream(l_line);
      linestream >> l_key >> l_uid;
      if (l_key == "Uid:") {
        return l_uid;
      }
    }
  }
  
  return l_uid; // Return an empty string if the file cannot be opened or the key is not found
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) //{ return string(); }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::string l_key{""};
  std::string l_user {""};
  std::string l_data {""};
  std::ifstream l_filestream(kPasswordPath);
  
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::replace(l_line.begin(), l_line.end(), ':', ' ');
      std::istringstream linestream(l_line);
      linestream >> l_user >> l_data >> l_key;
      if (l_key == Uid(pid)) {
        return l_user;
      }
    }
  }
  
  return l_user; // Return an empty string if the file cannot be opened or the key is not found
}
//[AuNV] (2023/10/02) <-----

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) //{ return 0; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  std::string l_line{""};
  std::ifstream l_filestream(kProcDirectory + "/" + std::to_string(pid) + kStatFilename);
  long l_uptime = 0;
  string l_value{""};
  if (l_filestream.is_open()) {
    while (std::getline(l_filestream, l_line)) {
      std::istringstream l_islinestream(l_line);
      for (int i = 1; i <= 22; i++) {
        l_islinestream >> l_value;
        if (i == 22) {
          // read the starttime value in clock ticks and convert to seconds
          // devide by clock ticks per second
          try {
            l_uptime = LinuxParser::UpTime() - std::stol(l_value) / sysconf(_SC_CLK_TCK);
            return l_uptime;
          } catch (const std::invalid_argument& arg) {
            return 0;
          }
        }
      }
    }
  }
  return l_uptime;
  
}
//[AuNV] (2023/10/02) <-----
