#include <unistd.h>
#include <cstddef>
#include <set>
#include <string>
#include <vector>

#include "process.h"
#include "processor.h"
#include "system.h"
#include "linux_parser.h" //[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/
using std::set;
using std::size_t;
using std::string;
using std::vector;
/*You need to complete the mentioned TODOs in order to satisfy the rubric criteria "The student will be able to extract and display basic data about the system."

You need to properly format the uptime. Refer to the comments mentioned in format. cpp for formatting the uptime.*/

// TODO: Return the system's CPU
Processor& System::Cpu() { return cpu_; }

// TODO: Return a container composed of the system's processes
vector<Process>& System::Processes() //{ return processes_; }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
  vector<Process> l_foundProcesses{};
  // read process IDs from file system and generate Vector
  vector<int> l_processIds = LinuxParser::Pids();
  for (int process : l_processIds) {
    Process pro{process};
    l_foundProcesses.push_back(pro);
  }

  // sort the processes according to their CPU usage
  sort(l_foundProcesses.begin(), l_foundProcesses.end(),
       [](const Process& pa, const Process& pb) {
         return (pb.CpuUtilization() < pa.CpuUtilization());
       });
  // update list of processes
  processes_ = l_foundProcesses;

  return processes_;
  /*
  processes_ = LinuxParser::Processes();
  std::sort(processes_.begin(), processes_.end());
  return processes_;
  */
}
//[AuNV] (2023/10/02) <-----

// TODO: Return the system's kernel identifier (string)
std::string System::Kernel() //{ return string(); }
//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise ----->
{
    return LinuxParser::Kernel();
}
//[AuNV] (2023/10/02) <-----
// TODO: Return the system's memory utilization
float System::MemoryUtilization() { return  LinuxParser::MemoryUtilization(); }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the operating system name
std::string System::OperatingSystem() { return LinuxParser::OperatingSystem(); }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the number of processes actively running on the system
int System::RunningProcesses() { return LinuxParser::RunningProcesses(); }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the total number of processes on the system
int System::TotalProcesses() { return  LinuxParser::TotalProcesses(); }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/

// TODO: Return the number of seconds since the system started running
long int System::UpTime() { return LinuxParser::UpTime(); }//[AuNV] (2023/10/02) System Monitor AuNV Do Exercise/
