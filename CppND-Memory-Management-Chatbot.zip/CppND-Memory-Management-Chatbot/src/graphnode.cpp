#include "graphedge.h"
#include "graphnode.h"

GraphNode::GraphNode(int id)
{
    _id = id;
}

GraphNode::~GraphNode()
{
    //// STUDENT CODE
    ////
    // [AuNV] [2023/10/03] del  code ----->
    //    delete _chatBot; 
    // [AuNV] [2023/10/03]  <-----
    ////
    //// EOF STUDENT CODE
}

void GraphNode::AddToken(std::string token)
{
    _answers.push_back(token);
}

void GraphNode::AddEdgeToParentNode(GraphEdge *edge)
{
    _parentEdges.push_back(edge);
}

// [AuNV] [2023/10/03] mod code ----->
// void GraphNode::AddEdgeToChildNode(GraphEdge *edge)
// {
//     _childEdges.push_back(edge);
// }
void GraphNode::AddEdgeToChildNode(std::unique_ptr<GraphEdge> edge)
{ 
    _childEdges.push_back(std::move(edge));
}
// [AuNV] [2023/10/03]  <-----

//// STUDENT CODE
////
void GraphNode::MoveChatbotHere(ChatBot l_ptrchatbot)
{
    // [AuNV] [2023/10/03] mod code ----->
        //_chatBot = chatbot;
       // _chatBot->SetCurrentNode(this);
        _chatBot = std::move(l_ptrchatbot);
        _chatBot.SetCurrentNode(this);   
    // [AuNV] [2023/10/03]  <-----

}

void GraphNode::MoveChatbotToNewNode(GraphNode *newNode)
{
    // [AuNV] [2023/10/03] mod code ----->
    // newNode->MoveChatbotHere(_chatBot);
    // _chatBot = nullptr; // invalidate pointer at source
    newNode->MoveChatbotHere(std::move(_chatBot));
   // _chatBot = nullptr; // invalidate pointer at source
    // [AuNV] [2023/10/03]  <-----
}
////
//// EOF STUDENT CODE

GraphEdge *GraphNode::GetChildEdgeAtIndex(int index)
{
    //// STUDENT CODE
    ////
    // [AuNV] [2023/10/03] mod code ----->
    //return _childEdges[index];
    return _childEdges[index].get();
    // [AuNV] [2023/10/03]  <-----
    ////
    //// EOF STUDENT CODE
}